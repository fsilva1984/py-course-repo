Preciso modificar o app, para ele mesmo mostrar o Qrcode
Por enquanto ele so gera uma imagem e salva em seu local atual
